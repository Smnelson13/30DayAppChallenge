//
//  InterestsCollectionViewCell.swift
//  Carousel
//
//  Created by Shane Nelson on 8/3/18.
//  Copyright © 2018 Shane Nelson. All rights reserved.
//

import UIKit

class InterestsCollectionViewCell: UICollectionViewCell {
  
  
}
