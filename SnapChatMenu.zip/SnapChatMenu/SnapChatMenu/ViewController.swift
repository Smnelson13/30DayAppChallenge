//
//  ViewController.swift
//  SnapChatMenu
//
//  Created by Shane Nelson on 8/2/18.
//  Copyright © 2018 Shane Nelson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  @IBOutlet weak var scrollView: UIScrollView!
  
  
  override func viewDidLoad() {
    super.viewDidLoad()
    UIApplication.shared.isStatusBarHidden = true
    let leftView: LeftViewController = LeftViewController(nibName: "LeftViewController", bundle: nil)
    let centerView: CameraViewController = CameraViewController(nibName: "CameraViewController", bundle: nil)
    let rightView: RightViewController = RightViewController(nibName: "RightViewController", bundle: nil)
    
    self.addChildViewController(leftView)
    self.scrollView.addSubview(leftView.view)
    leftView.didMove(toParentViewController: self)
    
    self.addChildViewController(rightView)
    self.scrollView.addSubview(rightView.view)
    rightView.didMove(toParentViewController: self)
    
    self.addChildViewController(centerView)
    self.scrollView.addSubview(centerView.view)
    rightView.didMove(toParentViewController: self)
    
    var centerFrameViewFrame: CGRect = centerView.view.frame
    centerFrameViewFrame.origin.x = self.view.frame.width
    centerView.view.frame = centerFrameViewFrame
    
    var rightViewFrameFrame: CGRect = rightView.view.frame
    rightViewFrameFrame.origin.x = 2 * self.view.frame.width
    rightView.view.frame = rightViewFrameFrame
    
    self.scrollView.contentSize = CGSize(width: self.view.frame.width * 3, height: self.view.frame.size.height)
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }


}

