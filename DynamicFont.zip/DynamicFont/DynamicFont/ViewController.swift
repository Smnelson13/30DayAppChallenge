//
//  ViewController.swift
//  DynamicFont
//
//  Created by Shane Nelson on 7/31/18.
//  Copyright © 2018 Shane Nelson. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

  @IBOutlet weak var label: UILabel!
  
  //let fontArrray = [UIFont(name:"Cochin",size:15),UIFont(name:"GillSans",size:15),UIFont(name:"Helvetica-Bold",size:15),UIFont(name:"MarkerFelt-Wide",size:15)]
  let fontArray = ["MarkerFelt-Wide", "Cochin", "GillSans", "Helvetica-Bold"]
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }

  @IBAction func buttonTap(_ sender: Any) {
    let arrayInt = Int(arc4random_uniform(UInt32(fontArray.count)))
    label.font = UIFont(name: fontArray[arrayInt], size: 20)
  }
  
}

