//
//  PullToRefreshTableViewController.swift
//  PullToRefresh
//
//  Created by Shane Nelson on 8/5/18.
//  Copyright © 2018 Shane Nelson. All rights reserved.
//

import UIKit

class PullToRefreshTableViewController: UITableViewController {
    
    struct User {
        let name: String
        let age: String
    }
    
    var users = [User(name: "Shane", age: "21"), User(name: "Chad", age: "23")]
    
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action:
            #selector(PullToRefreshTableViewController.handleRefresh(_:)),
                                 for: UIControlEvents.valueChanged)
        refreshControl.tintColor = UIColor.red
        
        return refreshControl
    }()
    
    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
        let newUser = User(name: "Gary", age: "51")
        users.append(newUser)
        self.tableView.reloadData()
        refreshControl.endRefreshing()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        cell.textLabel?.text = users[(indexPath as NSIndexPath).row].name
        cell.detailTextLabel?.text = users[(indexPath as NSIndexPath).row].age

        return cell
    }

    

}
