//
//  ViewController.swift
//  StopWatch
//
//  Created by Shane Nelson on 7/30/18.
//  Copyright © 2018 Shane Nelson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  @IBOutlet weak var timeLabel: UILabel!
  @IBOutlet weak var playButton: UIButton!
  @IBOutlet weak var pauseButton: UIButton!
  
  var timer = Timer()
  var timerIsRunning = false
  var counter = 0.0
  
  override func viewDidLoad() {
    super.viewDidLoad()
    timeLabel.text = "\(counter)"
    playButton.isEnabled = true
    pauseButton.isEnabled = false
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
  }

  @IBAction func playButtonTap(_ sender: Any) {
    if timerIsRunning != true {
      timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
      pauseButton.isEnabled = true
      playButton.isEnabled = false
    }
  }
  
  @IBAction func pauseButtonTap(_ sender: Any) {
    timer.invalidate()
    pauseButton.isEnabled = false
    playButton.isEnabled = true
  }
  
  @IBAction func resetButtonTap(_ sender: Any) {
    timer.invalidate()
    counter = 0
    timeLabel.text = "\(counter)"
    playButton.isEnabled = true
    pauseButton.isEnabled = false
  }

  @objc func updateTimer() {
    counter += 0.1
    timeLabel.text = String(format: "%.1f", counter)
  }
  
}

