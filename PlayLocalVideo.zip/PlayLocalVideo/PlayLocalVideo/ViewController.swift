//
//  ViewController.swift
//  PlayLocalVideo
//
//  Created by Shane Nelson on 8/1/18.
//  Copyright © 2018 Shane Nelson. All rights reserved.
//

import UIKit
import AVKit

class ViewController: UIViewController {
  
  override func viewDidLoad() {
    super.viewDidLoad()
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
  }

  @IBAction func playButtonTap(_ sender: Any) {
    if let path = Bundle.main.path(forResource: "IMG_2117", ofType: "mp4") {
      let video = AVPlayer(url: URL(fileURLWithPath: path))
      let videoPlayer = AVPlayerViewController()
      videoPlayer.player = video
      
      present(videoPlayer, animated: true, completion: {
        video.play()
      })
    }
  }
  
}

