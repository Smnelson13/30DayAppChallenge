//
//  ViewController.swift
//  LoginAnimation
//
//  Created by Shane Nelson on 8/12/18.
//  Copyright © 2018 Shane Nelson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var usernameTF: UITextField!
    @IBOutlet weak var usernameAlignCenter: NSLayoutConstraint!
    @IBOutlet weak var emailAlignCenter: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // Reset the labels position.
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        usernameAlignCenter.constant -= view.bounds.width
        emailAlignCenter.constant -= view.bounds.width
    }
    // Animate the labels position.
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        UIView.animate(withDuration: 0.5, delay: 0.00, options: .curveEaseOut, animations: {
            self.emailAlignCenter.constant += self.view.bounds.width
            self.view.layoutIfNeeded()
            
        }, completion: nil)
    
        UIView.animate(withDuration: 0.5, delay: 0.10, options: .curveEaseOut, animations: {
        self.usernameAlignCenter.constant += self.view.bounds.width
        self.view.layoutIfNeeded()
        
        }, completion: nil)
    }

    @IBAction func buttonTap(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}

