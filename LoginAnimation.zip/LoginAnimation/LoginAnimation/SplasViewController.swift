//
//  SplasViewController.swift
//  LoginAnimation
//
//  Created by Shane Nelson on 8/12/18.
//  Copyright © 2018 Shane Nelson. All rights reserved.
//

import UIKit

class SplasViewController: UIViewController {
    
    @IBOutlet weak var loginButon: UIButton!
    @IBOutlet weak var signUpButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        loginButon.layer.cornerRadius = 5
        signUpButton.layer.cornerRadius = 5
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginButtonTap(_ sender: Any) {
        
    }
    
    @IBAction func signUpButtonTap(_ sender: Any) {
        
    }
    
    func preferredStatusBarStyle() -> UIStatusBarStyle {
        return UIStatusBarStyle.lightContent
    }
    
}
