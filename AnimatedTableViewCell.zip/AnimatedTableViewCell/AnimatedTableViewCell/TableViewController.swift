//
//  TableViewController.swift
//  AnimatedTableViewCell
//
//  Created by Shane Nelson on 8/15/18.
//  Copyright © 2018 Shane Nelson. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    
    let array = ["Something", "Something else", "Another thing", "yet another thing", "Also another thing", "Some other other thing"]

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        animateTableViewCell()
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        cell.textLabel?.text = array[indexPath.row]

        return cell
    }
    
    func animateTableViewCell() {
        self.tableView.reloadData()
        let tableHeight: CGFloat = tableView.bounds.size.height
        let cell: [UITableViewCell] = tableView.visibleCells
        cell.forEach({ $0.transform = CGAffineTransform(translationX: 0, y: tableHeight)})
        var index = 0
        
        for i in cell {
            let cell: UITableViewCell = i as UITableViewCell
            UIView.animate(withDuration: 1.5, delay: 0.05 * Double(index), usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: [], animations: {
                cell.transform = CGAffineTransform(translationX: 0, y: 0);
            }, completion: nil)
            index += 1
        }
    }
}

