//
//  ViewController.swift
//  FindMyLocation
//
//  Created by Shane Nelson on 8/4/18.
//  Copyright © 2018 Shane Nelson. All rights reserved.
//

import CoreLocation
import UIKit

class ViewController: UIViewController, CLLocationManagerDelegate {
  
  let locationManager = CLLocationManager()

  @IBOutlet weak var locationLabel: UILabel!
    
  override func viewDidLoad() {
    super.viewDidLoad()
    checkStatus()
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    locationManager.delegate = self
  }
    
    func checkStatus() {
        if LocationAuthorization.isLocationServiceEnabled() == true {
            getLocation()
        } else {
            requestAuthorization()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let lat = locations.last?.coordinate.latitude, let long = locations.last?.coordinate.longitude {
            print("\(lat, long)")
        } else {
            print("Could not get coordinate.")
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error) // Quite possibly the easieset error handleing I have ever done.
    }
    
    func lookUpCurrentLocation(completion: @escaping (CLPlacemark?) -> Void ) {
        if let lastLocation = self.locationManager.location {
            let geoCoder = CLGeocoder()
            geoCoder.reverseGeocodeLocation(lastLocation, completionHandler: { placeMarks, error in
                if error == nil {
                    let firstLocation = placeMarks?[0]
                    completion(firstLocation)
                } else {
                    completion(nil)
                }
            })
        } else {
            completion(nil)
        }
    }
    

  
  @IBAction func goButtonTap(_ sender: Any) {
    locationManager.requestLocation()
  }

    func getLocation() {
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
    }
    
    func requestAuthorization() {
        let alertController = UIAlertController(title: "", message: "", preferredStyle: .alert)
        let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alertController.addAction(ok)
        OperationQueue.main.addOperation {
            self.present(alertController, animated: true, completion: nil)
        }
    }

}
