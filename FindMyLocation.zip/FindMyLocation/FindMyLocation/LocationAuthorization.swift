//
//  LocationAuthorization.swift
//  FindMyLocation
//
//  Created by Shane Nelson on 8/4/18.
//  Copyright © 2018 Shane Nelson. All rights reserved.
//

import Foundation
import CoreLocation

class LocationAuthorization {
    
    class func isLocationServiceEnabled() -> Bool {
        if CLLocationManager.locationServicesEnabled() {
            switch (CLLocationManager.authorizationStatus()) {
            case .notDetermined, .restricted, .denied:
                return false
            case .authorizedAlways, .authorizedWhenInUse:
                return true
            }
        } else {
            return false
        }
    }
}
